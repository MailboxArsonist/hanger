
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'matthewdodd93',
  applicationName: 'hanger-api-app',
  appUid: 'SrfzKRQZfcmJWGDppg',
  orgUid: 'c3238b29-665d-44fc-843a-c036fc53c6e3',
  deploymentUid: '27a68aab-f540-454a-81cd-283195a9ce9f',
  serviceName: 'hanger-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'hanger-api-dev-getWorkout', timeout: 6 };

try {
  const userHandler = require('./lambdas/endpoints/Workout/getWorkout.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}